package com.key.keyreception.activity.owner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.key.keyreception.R;

public class SubscriptionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscription);
    }
}
