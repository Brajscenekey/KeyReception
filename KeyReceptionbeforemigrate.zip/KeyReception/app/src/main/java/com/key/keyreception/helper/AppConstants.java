package com.key.keyreception.helper;

public class AppConstants {


    public static final String DEVICE_TYPE = "3";
    public static final int MY_PERMISSIONS_REQUEST_CEMERA_OR_GALLERY = 105;

    public static final int MY_PERMISSIONS_REQUEST_CEMERA = 103;
    //public final static int REQUEST_CAMERA = 0, SELECT_FILE = 1;
    public final static int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 123;
    //public static final int MY_PERMISSIONS_REQUEST_CAMERA = 101;
    public static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 102;


    public final static int MY_PERMISSIONS_REQUEST_CAMERA = 99;
    public static final int MY_PERMISSIONS_REQUEST_EXTERNAL = 100;

    public static final int CAMERA = 5;
    public static final int GALLERY = 6;

    public static final int REQUEST_CAMERA = 478;
    public static final int INTENT_CAMERA = 789;
    //public static final int RESULT_LOAD = 156;
    public static final int RESULT_LOAD = 156;

    public static final String OUTLOADER = "Livlouder";

    public static int checkIntenateKey = 0;



    public static final int REQUESTPERMISSIONCODE = 2;
    public static final int REQUEST_VIDEO_CAPTURE = 300;
    public static final int PROGRESS_BAR_MAX = 1000;
    public static final int SELECT_VIDEO_REQUEST = 0;
    public static final int RECORD_AUDIO = 15;
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 13;
}
