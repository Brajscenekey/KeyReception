package com.key.keyreception.activity.model;

/**
 * Created by Ravi Birla on 29,April,2019
 */
public class UploadImageModal {

    public String propertyId = "";
    public String propertyImage = "";
    public String imageid = "";
}
