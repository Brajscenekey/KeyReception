package com.key.keyreception.activity.model;

import java.util.List;

/**
 * Created by Ravi Birla on 01,May,2019
 */
public class ActivePropertyData {


    public boolean isclick = false;
    private int _id;
    private String propertyName;
    private String bedroom;
    private String bathroom;
    private String propertySize;
    private String propertyAddress;
    private String propertyLat;
    private String propertyLong;
    private String propertyCheckIn;
    private String propertyCheckOut;
    private int userId;
    private int status;
    private String crd;
    private String adminPropertyCalc;
    private List<PropertyImgBean> propertyImg;
    private List<OwnerDetailBean> ownerDetail;

    public ActivePropertyData(int _id, String propertyName, String bedroom, String bathroom, String propertySize, String propertyAddress, String propertyLat, String propertyLong, String propertyCheckIn, String propertyCheckOut, int userId, int status, String crd, String adminPropertyCalc, List<PropertyImgBean> propertyImg, List<OwnerDetailBean> ownerDetail) {
        this._id = _id;
        this.propertyName = propertyName;
        this.bedroom = bedroom;
        this.bathroom = bathroom;
        this.propertySize = propertySize;
        this.propertyAddress = propertyAddress;
        this.propertyLat = propertyLat;
        this.propertyLong = propertyLong;
        this.propertyCheckIn = propertyCheckIn;
        this.propertyCheckOut = propertyCheckOut;
        this.userId = userId;
        this.status = status;
        this.crd = crd;
        this.propertyImg = propertyImg;
        this.ownerDetail = ownerDetail;
        this.adminPropertyCalc = adminPropertyCalc;
    }

    public String getAdminPropertyCalc() {
        return adminPropertyCalc;
    }

    public void setAdminPropertyCalc(String adminPropertyCalc) {
        this.adminPropertyCalc = adminPropertyCalc;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getPropertyName() {
        return propertyName;
    }

    public void setPropertyName(String propertyName) {
        this.propertyName = propertyName;
    }

    public String getBedroom() {
        return bedroom;
    }

    public void setBedroom(String bedroom) {
        this.bedroom = bedroom;
    }

    public String getBathroom() {
        return bathroom;
    }

    public void setBathroom(String bathroom) {
        this.bathroom = bathroom;
    }

    public String getPropertySize() {
        return propertySize;
    }

    public void setPropertySize(String propertySize) {
        this.propertySize = propertySize;
    }

    public String getPropertyAddress() {
        return propertyAddress;
    }

    public void setPropertyAddress(String propertyAddress) {
        this.propertyAddress = propertyAddress;
    }

    public String getPropertyLat() {
        return propertyLat;
    }

    public void setPropertyLat(String propertyLat) {
        this.propertyLat = propertyLat;
    }

    public String getPropertyLong() {
        return propertyLong;
    }

    public void setPropertyLong(String propertyLong) {
        this.propertyLong = propertyLong;
    }

    public String getPropertyCheckIn() {
        return propertyCheckIn;
    }

    public void setPropertyCheckIn(String propertyCheckIn) {
        this.propertyCheckIn = propertyCheckIn;
    }

    public String getPropertyCheckOut() {
        return propertyCheckOut;
    }

    public void setPropertyCheckOut(String propertyCheckOut) {
        this.propertyCheckOut = propertyCheckOut;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getCrd() {
        return crd;
    }

    public void setCrd(String crd) {
        this.crd = crd;
    }

    public List<PropertyImgBean> getPropertyImg() {
        return propertyImg;
    }

    public void setPropertyImg(List<PropertyImgBean> propertyImg) {
        this.propertyImg = propertyImg;
    }

    public List<OwnerDetailBean> getOwnerDetail() {
        return ownerDetail;
    }

    public void setOwnerDetail(List<OwnerDetailBean> ownerDetail) {
        this.ownerDetail = ownerDetail;
    }

    public static class PropertyImgBean {
        /**
         * _id : 1
         * propertyImage : http://3.17.192.198:8042/uploads/property/prop_1556692957166.jpg
         */


        private int _id;
        private String propertyImage;
        public PropertyImgBean(int _id, String propertyImage) {
            this._id = _id;
            this.propertyImage = propertyImage;
        }

        public int get_id() {
            return _id;
        }

        public void set_id(int _id) {
            this._id = _id;
        }

        public String getPropertyImage() {
            return propertyImage;
        }

        public void setPropertyImage(String propertyImage) {
            this.propertyImage = propertyImage;
        }
    }

    public static class OwnerDetailBean {
        /**
         * _id : 2
         * profileImage :
         * fullName : deepika
         */


        private int _id;
        private String profileImage;
        private String fullName;
        public OwnerDetailBean(int _id, String profileImage, String fullName) {
            this._id = _id;
            this.profileImage = profileImage;
            this.fullName = fullName;
        }

        public int get_id() {
            return _id;
        }

        public void set_id(int _id) {
            this._id = _id;
        }

        public String getProfileImage() {
            return profileImage;
        }

        public void setProfileImage(String profileImage) {
            this.profileImage = profileImage;
        }

        public String getFullName() {
            return fullName;
        }

        public void setFullName(String fullName) {
            this.fullName = fullName;
        }
    }
}

