package com.key.keyreception.activity.model;

public class FirebaseUserModel {
    public String firebaseToken = "";
    public String name = "";
    //public String authtoken = "";
    public String email = "";
    public String usertype = "";
    public String profilePic = "";
    //  public Object timeStamp = "";
    public String uid = "";
}
